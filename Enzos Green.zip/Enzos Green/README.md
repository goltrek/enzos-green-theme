# Arc - In Colour

This Fork provides colour icons for minimise, maximise and close for the Arc GTK theme. It also changes the colour of the side pannel of the Thunar file manager, at the minute only supporting Xfce and GTK theming. 

![arc-incolour](https://i.imgur.com/GDJpSmO.png)
